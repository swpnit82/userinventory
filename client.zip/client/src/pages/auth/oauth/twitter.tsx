import React from 'react'

import { TwitterCallback } from '@xrengine/client-core/src/user/components/Oauth/Twitter'

export const TwitterHomePage = () => <TwitterCallback />

export default TwitterHomePage
