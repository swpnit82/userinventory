import React from 'react'
import ConfirmEmail from '@xrengine/client-core/src/user/components/Auth/ConfirmEmail'

export const ConfirmEmailPage = () => <ConfirmEmail />

export default ConfirmEmailPage
