export default () => {
    window.env = {publicRuntimeConfig: {}}
}