import sceneReducer from './scenes/reducers'

export default {
  scenes: sceneReducer
}
