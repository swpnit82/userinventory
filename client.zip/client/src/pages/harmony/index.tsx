import Layout from '../../components/Harmony/Layout'
import React from 'react'

const HarmonyPage = () => {
  return <Layout pageTitle="Harmony" />
}

export default HarmonyPage
