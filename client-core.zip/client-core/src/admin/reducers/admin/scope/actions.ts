import {
  SCOPE_FETCHING,
  SCOPE_ADMIN_RETRIEVED,
  REMOVE_SCOPE,
  ADD_SCOPE,
  UPDATE_SCOPE,
  SCOPE_TYPE_RETRIEVED
} from '../../actions'

export interface ScopeFetchingAction {
  type: string
}

export interface ScopeRetrieveAction {
  type: string
  list: any[]
}

export interface ScopeOneAction {
  type: string
  item: any
}

export interface FetchingScopeItemAction {
  type: string
  id: string
}

export type ScopeAction = ScopeRetrieveAction | ScopeOneAction | FetchingScopeItemAction

export function fetchingScope(): ScopeFetchingAction {
  return {
    type: SCOPE_FETCHING
  }
}

export function setAdminScope(list: any[]): ScopeRetrieveAction {
  return {
    type: SCOPE_ADMIN_RETRIEVED,
    list
  }
}

export function addAdminScope(item): ScopeOneAction {
  return {
    type: ADD_SCOPE,
    item
  }
}

export function updateAdminScope(result): ScopeAction {
  return {
    type: UPDATE_SCOPE,
    item: result
  }
}

export function removeScopeItem(id): FetchingScopeItemAction {
  return {
    type: REMOVE_SCOPE,
    id
  }
}

export const getScopeType = (item: any[]): ScopeRetrieveAction => ({
  type: SCOPE_TYPE_RETRIEVED,
  list: item
})
