import { createMappedComponent } from '@xrengine/engine/src/ecs/functions/ComponentFunctions'

export const GolfHoleComponent = createMappedComponent('GolfHoleComponent')
