export enum StarterGameCollisionGroups {
  Cube = 1 << 10
}
