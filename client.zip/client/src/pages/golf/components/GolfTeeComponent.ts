import { createMappedComponent } from '@xrengine/engine/src/ecs/functions/ComponentFunctions'

export const GolfTeeComponent = createMappedComponent('GolfTeeComponent')
