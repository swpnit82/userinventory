import React from 'react'

import { GoogleCallback } from '@xrengine/client-core/src/user/components/Oauth/GoogleCallback'

export const GoogleHomePage = () => <GoogleCallback />

export default GoogleHomePage
