export type TouchGamepadProps = {
  layout?: string
  onBoardingStep?: number | null
}
