import React from 'react'
import ForgotPassword from '@xrengine/client-core/src/user/components/Auth/ForgotPassword'

export const ForgotPasswordPage = () => <ForgotPassword />

export default ForgotPasswordPage
