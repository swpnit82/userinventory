import React from 'react'
import { FacebookCallback } from '@xrengine/client-core/src/user/components/Oauth/FacebookCallback'

export const FacebookHomePage = () => <FacebookCallback />

export default FacebookHomePage
