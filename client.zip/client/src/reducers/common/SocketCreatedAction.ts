export interface SocketCreatedAction {
  type: string
  socket: any
}
