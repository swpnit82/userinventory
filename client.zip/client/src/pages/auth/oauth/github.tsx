import React from 'react'

import { GithubCallback } from '@xrengine/client-core/src/user/components/Oauth/GithubCallback'

export const GithubHomePage = () => <GithubCallback />

export default GithubHomePage
