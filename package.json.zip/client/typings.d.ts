declare module '*.scss'
declare module '*.svg'
