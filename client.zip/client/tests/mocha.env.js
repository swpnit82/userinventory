// process.env.NODE_ENV = 'test'
process.env.TS_NODE_FILES = true
process.env.TS_NODE_PROJECT = 'tsconfig.json'
process.env.TS_NODE_COMPILER_OPTIONS = '{\"module\": \"commonjs\" }'
