import React from 'react'

import { LinkedinCallback } from '@xrengine/client-core/src/user/components/Oauth/LinkedinCallBack'

export const LinkedInHomePage = () => <LinkedinCallback />

export default LinkedInHomePage
