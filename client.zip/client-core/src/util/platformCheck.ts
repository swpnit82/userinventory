export const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream
