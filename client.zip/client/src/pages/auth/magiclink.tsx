import React from 'react'
import AuthMagicLink from '@xrengine/client-core/src/user/components/MagicLink/AuthMagicLink'

export const AuthMagicLinkPage = () => <AuthMagicLink />

export default AuthMagicLinkPage
