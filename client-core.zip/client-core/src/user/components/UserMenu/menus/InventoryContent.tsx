import Button from '@material-ui/core/Button'
import InputAdornment from '@material-ui/core/InputAdornment'
import TextField from '@material-ui/core/TextField'
import Typography from '@material-ui/core/Typography'
import {
    DialogTitle,
    Dialog,
    DialogContent,
    DialogActions,
    makeStyles,
    Grid,
    Divider
    // Stack
} from '@material-ui/core'
import { Check, Close, Create, GitHub, Send, Cancel, ArrowBackIos } from '@material-ui/icons'
import { useAuthState } from '../../../reducers/auth/AuthState'
import { AuthService } from '../../../reducers/auth/AuthService'
import { Network } from '@xrengine/engine/src/networking/classes/Network'
import React, { useEffect, useState } from 'react'
import { connect, useDispatch } from 'react-redux'
import { bindActionCreators, Dispatch } from 'redux'
import { FacebookIcon } from '../../../../common/components/Icons/FacebookIcon'
import { GoogleIcon } from '../../../../common/components/Icons/GoogleIcon'
import { LinkedInIcon } from '../../../../common/components/Icons/LinkedInIcon'
import { TwitterIcon } from '../../../../common/components/Icons/TwitterIcon'
import { getAvatarURLForUser, Views } from '../util'
import { Config, validateEmail, validatePhoneNumber } from '@xrengine/common/src/config'
import * as polyfill from 'credential-handler-polyfill'
import styles from '../UserMenu.module.scss'
import { useTranslation } from 'react-i18next'
import { Box, Card, FormControl, IconButton, InputLabel, LinearProgress, MenuItem, Select, Stack } from '@mui/material'
import { useHistory } from 'react-router-dom'

// interface Props {
//     changeActiveMenu?: any
//     setProfileMenuOpen?: any

//     hideLogin?: any
// }

const useStyles = makeStyles({
    root: {
        width: '50%',
        height: '100vh',
        boxShadow: '16px 16px 16px 16px #11111159',
        margin: '20px',
        borderadius: '10px'
    },
    item: {
        border: 'solid 1px',
        borderRadius: '5px',
        borderColor: '#d9d7d78c',
        cursor: 'pointer'
    },
    modalBody: {
        backgroundColor: "#FFF"
    },
    modalBoxShadow: {
        boxShadow: "0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24)",
        transition: "all 0.3s cubic-bezier(.25,.8,.25,1)",
        backgroundColor: "white"
    },
    itemscroll: {
        maxHeight: '500px',
        overflowY: 'auto',
    }
})


const InventoryContent = ({ data, user, handleTransfer }: any) => {
    // const { changeActiveMenu, setProfileMenuOpen, hideLogin,data } = props
    const { t } = useTranslation()
    const history = useHistory()
    const dispatch = useDispatch()
    const selfUser = useAuthState().user
    const classes = useStyles()
    const [state, setState] = useState({ url: '', metadata: '', selectedid: '', userid: '' })
    const { url, metadata, userid,selectedid } = state

    useEffect(() => {
        setState(prevState => ({
            ...prevState,
            url: data[0].url,
            metadata: data[0].metadata,
            selectedid: data[0].user_inventory.userInventoryId
        }))
    }, [])



    // metadata.length!==0 && console.log(JSON.parse(metadata),typeof data[0].metadata, 'data')
    console.log(data, user)
    return (

        // <div className={styles.menuPanel}>
        <Stack justifyContent="center"
            alignItems="center">
            <Card className={classes.root}>
                <Stack sx={{ p: 2 }} spacing={2}>
                    <Stack direction="row" justifyContent="space-between">
                        <IconButton onClick={() => history.goBack()}>
                            <ArrowBackIos /> Back
                        </IconButton>
                        <Typography>Inventory</Typography>
                    </Stack>
                    <Stack justifyContent="center" alignItems="center" sx={{ p: 2 }}>

                        <Grid container spacing={6}>
                            <Grid item xs={4} className={classes.itemscroll}>

                                <Stack >
                                    {data.map((value: any, index: number) => (
                                        <Card key={index} onClick={() => {
                                            setState(prevState => ({
                                                ...prevState,
                                                url: value.url,
                                                metadata: value.metadata,
                                                selectedid: value.inventoryItemId
                                            }))
                                        }}><Stack spacing={1} className={classes.item} >
                                                <Stack>
                                                    <img src={value.url} alt="" />
                                                </Stack>
                                            </Stack></Card>


                                    ))}
                                </Stack>



                            </Grid>
                            <Grid item xs={8} className={classes.itemscroll}>
                                <Stack justifyContent="flex-start">
                                    <Stack>
                                        <Stack spacing={3} justifyContent="center" alignItems="center">
                                            <img src={url} height='100' width='100' alt="" />
                                        </Stack>
                                        <Stack spacing={3} justifyContent="flex-start" alignItems="center">
                                            {metadata.length !== 0 && <Stack spacing={3}>
                                                {JSON.parse(metadata).map((val, index) => (
                                                    <Typography variant="h6" key={index}>
                                                        {val.trait_type}:{(val.trait_type !== 'personality' && val.trait_type !== 'age') ? <Box sx={{ width: '50%', mr: 1 }}>
                                                            <LinearProgress variant="determinate" value={val.value} />
                                                        </Box> : `${val.value}`}
                                                    </Typography>
                                                ))}
                                            </Stack>}
                                        </Stack>
                                        <Stack justifyContent="center" alignItems="center" spacing={1} direction="row">
                                            <FormControl fullWidth>
                                                <InputLabel id="demo-simple-select-label">User</InputLabel>
                                                <Select
                                                    labelId="demo-simple-select-label"
                                                    id="demo-simple-select"
                                                    value={userid}
                                                    label="user"
                                                    onChange={(e: any) => {
                                                        setState(prevState => ({
                                                            ...prevState,
                                                            userid: e.target.value
                                                        }))
                                                    }}
                                                >
                                                    {user.map((datas, index) => <MenuItem key={index} value={datas.id}>{datas.name}</MenuItem>)}
                                                </Select>
                                            </FormControl>
                                            <Button variant="outlined" onClick={()=>handleTransfer(userid,selectedid)}>Transfer</Button>
                                        </Stack>
                                    </Stack>

                                </Stack>
                            </Grid>
                        </Grid>
                    </Stack>

                </Stack>
            </Card>
        </Stack>
        // </div>

    )
}

export default InventoryContent;
