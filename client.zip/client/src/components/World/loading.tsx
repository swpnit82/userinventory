import React from 'react'
const Loading = () => (
  <div>
    <h3>Loading...</h3>
  </div>
)

export default Loading
